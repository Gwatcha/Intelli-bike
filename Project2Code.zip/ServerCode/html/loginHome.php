<?php

$servername = "localhost";
$username = "phone";
$password = "Coming2Program/EngineerNothing";
$db = "phone_push";

?>
