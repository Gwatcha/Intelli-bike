<?php
$rootFolder= "/var/www/html/uploads/";
?>
